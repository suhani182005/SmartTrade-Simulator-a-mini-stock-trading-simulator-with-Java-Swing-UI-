package main;

import ui.TradeDashboard;

public class SmartTradeApp {
    public static void main(String[] args) {
        javax.swing.SwingUtilities.invokeLater(() -> {
            new TradeDashboard().setVisible(true);
        });
    }
}
