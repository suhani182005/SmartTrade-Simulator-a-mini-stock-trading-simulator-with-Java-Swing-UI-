package utils;

import java.io.*;
import java.util.*;

public class FileHandler {
    public static void saveData(String filename, String data) {
        try (FileWriter fw = new FileWriter(filename)) {
            fw.write(data);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static String loadData(String filename) {
        StringBuilder data = new StringBuilder();
        try (Scanner sc = new Scanner(new File(filename))) {
            while (sc.hasNextLine()) {
                data.append(sc.nextLine()).append("\n");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return data.toString();
    }
}
