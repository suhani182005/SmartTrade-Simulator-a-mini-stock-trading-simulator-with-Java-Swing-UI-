package model;

import java.util.HashMap;

public class Portfolio {
    private HashMap<String, Stock> stocks;

    public Portfolio() {
        stocks = new HashMap<>();
    }

    public void buyStock(String symbol, int qty) {
        Stock stock = stocks.get(symbol);
        if (stock == null) {
            stock = new Stock(symbol, 100.0, qty); // default price
            stocks.put(symbol, stock);
        } else {
            stock.addQuantity(qty);
        }
        System.out.println("Bought " + qty + " shares of " + symbol);
    }

    public void sellStock(String symbol, int qty) {
        Stock stock = stocks.get(symbol);
        if (stock != null && stock.getQuantity() >= qty) {
            stock.removeQuantity(qty);
            System.out.println("Sold " + qty + " shares of " + symbol);
        } else {
            System.out.println("Not enough shares to sell or stock not found.");
        }
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("Portfolio:\n");
        for (Stock s : stocks.values()) {
            sb.append(s.toString()).append("\n");
        }
        return sb.toString();
    }
}
