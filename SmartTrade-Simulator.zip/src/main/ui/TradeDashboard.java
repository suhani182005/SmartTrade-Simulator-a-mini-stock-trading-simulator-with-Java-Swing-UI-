package ui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import model.*;

public class TradeDashboard extends JFrame {
    private Portfolio portfolio;

    public TradeDashboard() {
        portfolio = new Portfolio();
        setTitle("SmartTrade Simulator");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setupUI();
    }

    private void setupUI() {
        JLabel title = new JLabel("SmartTrade Simulator", SwingConstants.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 24));
        JButton buyButton = new JButton("Buy Stock");
        JButton sellButton = new JButton("Sell Stock");
        JButton viewButton = new JButton("View Portfolio");

        JPanel panel = new JPanel();
        panel.add(buyButton);
        panel.add(sellButton);
        panel.add(viewButton);

        add(title, BorderLayout.NORTH);
        add(panel, BorderLayout.CENTER);

        buyButton.addActionListener(e -> portfolio.buyStock("AAPL", 5));
        sellButton.addActionListener(e -> portfolio.sellStock("AAPL", 2));
        viewButton.addActionListener(e -> JOptionPane.showMessageDialog(this, portfolio.toString()));
    }
}
